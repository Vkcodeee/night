
import configparser

config = configparser.ConfigParser()
config.read("settings.ini")
BOT_TOKEN = config["settings"]["token"]
admin_for_logs = config["settings"]["admin_id"]
admins = config["settings"]["admin_id"]
api_id = config["settings"]["api_id"]
api_hash = config["settings"]["api_hash"]
if "," in admins:
    admins = admins.split(",")
else:
    if len(admins) >= 3:
        admins = [admins]
    else:
        admins = [1262698058]
        print("***** Вы не указали админ ID *****")

bot_version = "1.12"
bot_description = f"<b>▫️Разработчик: @iUniversal01</b>\n" \
                  f"<b>▫️Версия:</b> <code>{bot_version}</code>\n" \
                  f"<b>▫️Новости и обновления:</b> <a href='https://vk.com/minesoul_srv'><b>перейти</b></a>\n"
